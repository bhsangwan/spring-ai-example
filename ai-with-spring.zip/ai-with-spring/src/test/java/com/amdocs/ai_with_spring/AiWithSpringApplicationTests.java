package com.amdocs.ai_with_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiWithSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
