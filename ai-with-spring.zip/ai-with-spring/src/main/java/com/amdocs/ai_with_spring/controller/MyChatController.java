package com.amdocs.ai_with_spring.controller;

import java.io.IOException;

import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.ai_with_spring.service.ChatService;

@RestController
@RequestMapping("/ai")
public class MyChatController {

	@Autowired
	ChatService chatService;
	
	@PostMapping("/chat")
	public ChatResponse generateChatResponse(@RequestParam String category, String year) {
		
		//return chatService.getChatResponse(category, year).getResult().getOutput().getContent();
		return chatService.getChatResponse(category, year);
	}
	
	@PostMapping("/images/chat")
	public String generateImageResponse(@RequestParam String query) throws IOException{
		
		return chatService.getImageResponse(query);
	}
	
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello World..!";
	}
}
