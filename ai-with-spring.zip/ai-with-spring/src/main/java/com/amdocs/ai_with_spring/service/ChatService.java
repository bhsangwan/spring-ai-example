package com.amdocs.ai_with_spring.service;

import java.util.List;

import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.model.Media;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

@Service
public class ChatService {

	@Autowired
	ChatModel chatClient;
	
	public ChatResponse getChatResponse(String category, String year) {
		
		PromptTemplate promptTemplate = new PromptTemplate(
				"""
				Please suggest me a good book for the given {category} and the {year}.
				Provide the summary of the book in limited words, not so much in deep. Also provide the 
				information in the JSON format containing following information: category, book, year, reviews, author, summary 
				"""
				);
		
		promptTemplate.add("category", category);
		promptTemplate.add("year", year);
		
		Prompt prompt = promptTemplate.create();
		
		return chatClient.call(prompt);
	}
	
	public String getImageResponse(String query) {
		
		//byte[] date = new ClassPathResource("/image/img1.png").getContentAsByteArray();
		
		var imageResource = new ClassPathResource("/images/img2.png");
		
		UserMessage userMessage = new UserMessage(query, List.of(new Media(MimeTypeUtils.IMAGE_PNG, imageResource)));
		
		Prompt prompt = new Prompt(userMessage);
		
		var response = chatClient.call(prompt);
		
		return response.getResult().getOutput().getContent();
	}
	
}








